# Changelog

All notable changes to this project will be documented in this file.

## [1.0.2] - 2019-03-30

### Fixed

- Fixed scrollbar from showing on tabs

## [1.0.1] - 2019-03-25

### Added

- Added Changelog
- Destructured the props on functional components
- Stopped app from scrolling when scrolling through sidebar navigation in mobile
- Sidebar will collapse when selecting a new route in mobile view
- Performance improvements

### Fixed

- Fixed 'Skip to Content' link

## [1.0.0] - 2019-03-17

- Initial release.
