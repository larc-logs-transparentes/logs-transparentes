import React from 'react';

const NavSpacer = () => {
  return <li className="nav-item nav-item-spacer" />;
};

export default NavSpacer;
